package com.zork;

public interface ZorkXMLParser {
    /**
     * used to parse different types of org.w3c.dom.Element objects in different implementations
     * @return
     */
    Object parseElement();
}
